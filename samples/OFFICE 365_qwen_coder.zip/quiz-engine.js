/**
 * quiz-engine.js
 * Motor de evaluación para las autoevaluaciones de cada unidad.
 * Calcula nota local y reporta al SCORM.
 */

var QuizEngine = {
    currentUnitId: null,
    questions: [],
    score: 0,

    /**
     * Inicializa el quiz con los datos de la unidad actual.
     * @param {string} unitId - Identificador de la unidad (ej: 'unit1')
     * @param {Array} questionsData - Array de objetos pregunta
     */
    init: function(unitId, questionsData) {
        this.currentUnitId = unitId;
        this.questions = questionsData;
        this.renderQuiz();
    },

    /**
     * Renderiza el HTML del quiz en el contenedor #quiz-container
     */
    renderQuiz: function() {
        var container = document.getElementById('quiz-container');
        if (!container) return;

        var html = '<div class="quiz-header"><h3>Autoevaluación</h3><p>Responde para completar la unidad.</p></div>';
        
        this.questions.forEach((q, index) => {
            html += `<div class="question-block" id="q-block-${index}">
                <span class="question-text">${index + 1}. ${q.text}</span>
                <div class="options">`;
            
            q.options.forEach((opt, optIndex) => {
                html += `
                    <label>
                        <input type="radio" name="question${index}" value="${optIndex}">
                        ${opt}
                    </label>`;
            });

            html += `</div><div class="feedback" id="feedback-${index}" style="display:none;"></div></div>`;
        });

        html += `<button onclick="QuizEngine.submitQuiz()">Enviar Respuestas</button>`;
        html += `<div id="final-score" style="margin-top:1rem; font-weight:bold;"></div>`;
        
        container.innerHTML = html;
    },

    /**
     * Valida las respuestas y calcula la puntuación.
     */
    submitQuiz: function() {
        var totalQuestions = this.questions.length;
        var correctCount = 0;
        var allAnswered = true;

        this.questions.forEach((q, index) => {
            var selected = document.querySelector(`input[name="question${index}"]:checked`);
            var feedbackEl = document.getElementById(`feedback-${index}`);
            
            if (!selected) {
                allAnswered = false;
                return;
            }

            var isCorrect = parseInt(selected.value) === q.correct;
            if (isCorrect) correctCount++;

            // Mostrar feedback visual
            feedbackEl.style.display = 'block';
            if (isCorrect) {
                feedbackEl.textContent = "¡Correcto!";
                feedbackEl.className = "feedback correct";
            } else {
                feedbackEl.textContent = "Incorrecto. La respuesta correcta era otra.";
                feedbackEl.className = "feedback incorrect";
            }
            
            // Deshabilitar inputs tras enviar
            var inputs = document.querySelectorAll(`input[name="question${index}"]`);
            inputs.forEach(inp => inp.disabled = true);
        });

        if (!allAnswered) {
            alert("Por favor, responde todas las preguntas antes de enviar.");
            // Re-habilitar si falló validación básica (opcional, aquí simplificamos)
            location.reload(); 
            return;
        }

        // Cálculo de nota (0 a 100)
        var rawScore = Math.round((correctCount / totalQuestions) * 100);
        this.score = rawScore;

        var scoreEl = document.getElementById('final-score');
        scoreEl.textContent = `Puntuación: ${rawScore}/100`;

        // Actualizar estado SCORM
        this.updateSCORMStatus(rawScore);
    },

    /**
     * Reporta el estado y la nota al LMS.
     */
    updateSCORMStatus: function(score) {
        // Marcar como completado si la nota es >= 70 (umbral típico) o simplemente por finalizar
        var status = (score >= 70) ? "passed" : "completed"; 
        
        SCORM.setValue("cmi.core.lesson_status", status);
        SCORM.setValue("cmi.core.score.raw", score);
        
        // Guardar progreso inmediato
        SCORM.save();
        
        console.log(`SCORM Actualizado: Status=${status}, Score=${score}`);
        
        // Deshabilitar botón de enviar
        var btn = document.querySelector('#quiz-container button');
        if(btn) btn.disabled = true;
        if(btn) btn.textContent = "Evaluación Completada";
    }
};