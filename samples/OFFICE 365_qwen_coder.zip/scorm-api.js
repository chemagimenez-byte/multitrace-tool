/**
 * scorm-api.js
 * Implementación de la API SCORM 1.2 para comunicación con el LMS (Moodle).
 * Maneja inicialización, lectura/escritura de datos y cierre de sesión.
 */

var SCORM = {
    initialized: false,
    api: null,
    debugMode: false, // Cambiar a true para ver logs en consola

    /**
     * Inicializa la conexión con el LMS.
     * Busca el objeto API en window o window.parent.
     */
    init: function() {
        this.api = this.getAPI();
        
        if (this.api === null) {
            console.error("SCORM: No se encontró la API del LMS.");
            return false;
        }

        var result = this.api.LMSInitialize("");
        if (result === "true") {
            this.initialized = true;
            this.log("SCORM inicializado correctamente.");
            
            // Recuperar estado previo si existe
            var status = this.getValue("cmi.core.lesson_status");
            if(status === "") this.setValue("cmi.core.lesson_status", "incomplete");
            
            return true;
        } else {
            var errorCode = this.api.LMSGetLastError();
            console.error("SCORM Error al inicializar: " + errorCode);
            return false;
        }
    },

    /**
     * Busca el objeto API en las ventanas disponibles.
     */
    getAPI: function() {
        var api = window.API;
        var parent = window.parent;
        
        // Búsqueda estándar SCORM 1.2
        while (parent != null && api == null) {
            api = parent.API;
            parent = parent.parent;
        }
        return api;
    },

    /**
     * Obtiene un valor del LMS.
     * @param {string} parameter - Ej: "cmi.core.student_name"
     */
    getValue: function(parameter) {
        if (!this.initialized || !this.api) return "";
        var value = this.api.LMSGetValue(parameter);
        var error = this.api.LMSGetLastError();
        if (error !== "0") {
            this.log("Error getValue (" + error + "): " + parameter);
        }
        return value;
    },

    /**
     * Establece un valor en el LMS.
     * @param {string} parameter - Ej: "cmi.core.score.raw"
     * @param {string|number} value
     */
    setValue: function(parameter, value) {
        if (!this.initialized || !this.api) return false;
        var result = this.api.LMSSetValue(parameter, value);
        if (result === "true") {
            return true;
        } else {
            var error = this.api.LMSGetLastError();
            this.log("Error setValue (" + error + "): " + parameter + " = " + value);
            return false;
        }
    },

    /**
     * Guarda los datos (Commit) sin cerrar la sesión.
     */
    save: function() {
        if (!this.initialized || !this.api) return false;
        var result = this.api.LMSCommit("");
        if (result === "true") {
            this.log("Datos guardados (Commit).");
            return true;
        }
        return false;
    },

    /**
     * Finaliza la sesión SCORM.
     */
    finish: function() {
        if (!this.initialized || !this.api) return false;
        var result = this.api.LMSFinish("");
        if (result === "true") {
            this.initialized = false;
            this.log("Sesión SCORM finalizada.");
            return true;
        }
        return false;
    },

    /**
     * Utilidad para logs condicionales.
     */
    log: function(msg) {
        if (this.debugMode) console.log("[SCORM]", msg);
    }
};

// Inicializar automáticamente al cargar el script
window.addEventListener('load', function() {
    SCORM.init();
});

// Intentar guardar al cerrar la pestaña/navegador
window.addEventListener('beforeunload', function() {
    if(SCORM.initialized) {
        SCORM.save();
        // Nota: LMSFinish suele llamarse explícitamente al terminar el curso, no aquí,
        // para permitir reanudar. Pero algunos LMS requieren finish en unload.
        // Para este diseño, usaremos un botón explícito "Salir" o lo manejamos en la última unidad.
    }
});