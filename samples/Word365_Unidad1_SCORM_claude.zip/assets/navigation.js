/* =========================================================
   Navegación interna del SCO Unidad 1 - Word 365
   ========================================================= */

var PAGES = [
    "pages/01-bienvenida.html",
    "pages/02-introduccion.html",
    "pages/03-interfaz.html",
    "pages/04-primer-documento.html",
    "pages/05-formato-basico.html",
    "pages/06-guardar.html",
    "pages/07-cuestionario.html"
];

var PAGE_TITLES = [
    "Bienvenida",
    "Introducción a Word 365",
    "La interfaz de Word",
    "Crear tu primer documento",
    "Formato básico de texto",
    "Guardar y compartir",
    "Cuestionario final"
];

function getCurrentIndex() {
    var iframe = document.getElementById("contentFrame");
    if (!iframe || !iframe.src) return 0;
    var src = iframe.src.split("#")[0];
    for (var i = 0; i < PAGES.length; i++) {
        if (src.indexOf(PAGES[i]) !== -1) return i;
    }
    return 0;
}

function loadPage(index) {
    if (index < 0) index = 0;
    if (index >= PAGES.length) index = PAGES.length - 1;
    var iframe = document.getElementById("contentFrame");
    iframe.src = PAGES[index];
    updateUI(index);
    if (typeof SCORM !== "undefined" && SCORM.isInitialized()) {
        SCORM.setValue("cmi.core.lesson_location", String(index));
        SCORM.commit();
    }
}

function nextPage() {
    var i = getCurrentIndex();
    loadPage(i + 1);
}

function prevPage() {
    var i = getCurrentIndex();
    loadPage(i - 1);
}

function gotoPage(index) {
    loadPage(index);
}

function updateUI(index) {
    /* Botones */
    var prev = document.getElementById("btnPrev");
    var next = document.getElementById("btnNext");
    if (prev) prev.disabled = (index === 0);
    if (next) next.disabled = (index === PAGES.length - 1);

    /* Progreso */
    var bar = document.getElementById("progressBar");
    if (bar) {
        var pct = ((index + 1) / PAGES.length) * 100;
        bar.style.width = pct + "%";
        bar.setAttribute("aria-valuenow", String(Math.round(pct)));
    }
    var pageInfo = document.getElementById("pageInfo");
    if (pageInfo) {
        pageInfo.textContent = "Página " + (index + 1) + " de " + PAGES.length + " · " + PAGE_TITLES[index];
    }

    /* Menú lateral */
    var items = document.querySelectorAll(".menu-item");
    for (var i = 0; i < items.length; i++) {
        if (i === index) items[i].classList.add("active");
        else items[i].classList.remove("active");
    }
}

function buildMenu() {
    var menu = document.getElementById("sideMenu");
    if (!menu) return;
    var html = "";
    for (var i = 0; i < PAGE_TITLES.length; i++) {
        html += '<li class="menu-item" onclick="gotoPage(' + i + ')">'
              + '<span class="menu-num">' + (i + 1) + '</span>'
              + '<span class="menu-title">' + PAGE_TITLES[i] + '</span>'
              + '</li>';
    }
    menu.innerHTML = html;
}

/* Recibir mensajes desde las páginas hijas (cuestionario) */
window.addEventListener("message", function (event) {
    if (!event.data || typeof event.data !== "object") return;
    if (event.data.type === "scorm:quizResult") {
        var score = Number(event.data.score) || 0;
        if (typeof SCORM !== "undefined") {
            SCORM.setPassed(score);
        }
    }
    if (event.data.type === "scorm:complete") {
        if (typeof SCORM !== "undefined") {
            SCORM.setCompleted();
        }
    }
});

/* Inicializar */
window.addEventListener("DOMContentLoaded", function () {
    buildMenu();
    /* Restaurar última página visitada si existe */
    var lastLocation = 0;
    if (typeof SCORM !== "undefined" && SCORM.isInitialized()) {
        var loc = SCORM.getValue("cmi.core.lesson_location");
        if (loc && !isNaN(parseInt(loc, 10))) {
            lastLocation = parseInt(loc, 10);
        }
    }
    loadPage(lastLocation);
});
