/* =========================================================
   SCORM 1.2 API Wrapper
   Acción Formativa: Cómo usar Word 365 - Unidad 1
   Compatible con Moodle (SCORM 1.2)
   ========================================================= */

var SCORM = (function () {
    var API = null;
    var initialized = false;
    var finished = false;
    var findAttempts = 0;
    var maxFindAttempts = 500;

    /* Busca la API SCORM 1.2 (objeto window.API) en la cadena de ventanas */
    function findAPI(win) {
        while ((win.API == null) && (win.parent != null) && (win.parent != win)) {
            findAttempts++;
            if (findAttempts > maxFindAttempts) {
                return null;
            }
            win = win.parent;
        }
        return win.API;
    }

    function getAPI() {
        var theAPI = null;
        if ((window.parent != null) && (window.parent != window)) {
            theAPI = findAPI(window.parent);
        }
        if ((theAPI == null) && (window.opener != null)) {
            theAPI = findAPI(window.opener);
        }
        return theAPI;
    }

    function init() {
        if (initialized) return true;
        API = getAPI();
        if (API == null) {
            console.warn("[SCORM] No se encontró la API SCORM 1.2. Ejecutando en modo standalone.");
            return false;
        }
        var result = API.LMSInitialize("");
        if (result.toString() === "true") {
            initialized = true;
            // Marca el estado inicial
            var status = API.LMSGetValue("cmi.core.lesson_status");
            if (status === "not attempted" || status === "") {
                API.LMSSetValue("cmi.core.lesson_status", "incomplete");
                API.LMSCommit("");
            }
            return true;
        }
        return false;
    }

    function setValue(key, value) {
        if (!initialized || API == null) return false;
        var result = API.LMSSetValue(key, value);
        return result.toString() === "true";
    }

    function getValue(key) {
        if (!initialized || API == null) return "";
        return API.LMSGetValue(key);
    }

    function commit() {
        if (!initialized || API == null) return false;
        return API.LMSCommit("").toString() === "true";
    }

    function finish() {
        if (!initialized || API == null || finished) return false;
        commit();
        var result = API.LMSFinish("");
        finished = true;
        return result.toString() === "true";
    }

    function setCompleted() {
        setValue("cmi.core.lesson_status", "completed");
        commit();
    }

    function setPassed(scorePercent) {
        setValue("cmi.core.score.raw", String(Math.round(scorePercent)));
        setValue("cmi.core.score.min", "0");
        setValue("cmi.core.score.max", "100");
        if (scorePercent >= 70) {
            setValue("cmi.core.lesson_status", "passed");
        } else {
            setValue("cmi.core.lesson_status", "failed");
        }
        commit();
    }

    function getStudentName() {
        return getValue("cmi.core.student_name") || "Alumno/a";
    }

    /* Cierra la sesión SCORM cuando se cierra la ventana */
    window.addEventListener("beforeunload", function () {
        try { finish(); } catch (e) { /* noop */ }
    });

    return {
        init: init,
        finish: finish,
        commit: commit,
        setValue: setValue,
        getValue: getValue,
        setCompleted: setCompleted,
        setPassed: setPassed,
        getStudentName: getStudentName,
        isInitialized: function () { return initialized; }
    };
})();

/* Inicializar automáticamente al cargar */
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () { SCORM.init(); });
} else {
    SCORM.init();
}
