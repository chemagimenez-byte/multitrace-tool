(function () {
  var panels = Array.prototype.slice.call(document.querySelectorAll(".panel"));
  var navItems = Array.prototype.slice.call(document.querySelectorAll(".nav-item"));
  var progressLabel = document.getElementById("progressLabel");
  var statusLabel = document.getElementById("statusLabel");
  var quizForm = document.getElementById("quizForm");
  var result = document.getElementById("result");
  var visited = {};
  var totalSections = panels.length;

  function setStatus(text) {
    statusLabel.textContent = "Estado: " + text;
  }

  function updateProgress() {
    var count = Object.keys(visited).length;
    var progress = Math.round((count / totalSections) * 100);
    progressLabel.textContent = progress + "%";
    if (window.SCORM) {
      window.SCORM.set("cmi.core.lesson_location", count + "/" + totalSections);
      window.SCORM.set("cmi.core.score.raw", Math.min(progress, 79));
      window.SCORM.commit();
    }
  }

  function showPanel(id) {
    panels.forEach(function (panel) {
      panel.classList.toggle("active", panel.id === id);
    });
    navItems.forEach(function (item) {
      item.classList.toggle("active", item.dataset.target === id);
    });
    visited[id] = true;
    updateProgress();
  }

  function completeCourse(score) {
    progressLabel.textContent = "100%";
    setStatus(score >= 80 ? "completado y aprobado" : "completado sin superar");
    if (window.SCORM) {
      window.SCORM.set("cmi.core.score.raw", score);
      window.SCORM.set("cmi.core.lesson_status", score >= 80 ? "passed" : "failed");
      window.SCORM.commit();
    }
  }

  navItems.forEach(function (item) {
    item.addEventListener("click", function () {
      showPanel(item.dataset.target);
    });
  });

  document.querySelectorAll(".next").forEach(function (button) {
    button.addEventListener("click", function () {
      showPanel(button.dataset.next);
    });
  });

  quizForm.addEventListener("submit", function (event) {
    event.preventDefault();
    var score = 0;
    ["q1", "q2", "q3"].forEach(function (name) {
      var selected = quizForm.querySelector("input[name='" + name + "']:checked");
      if (selected && selected.value === "1") {
        score += 1;
      }
    });
    var percent = Math.round((score / 3) * 100);
    result.hidden = false;
    result.className = "result " + (percent >= 80 ? "pass" : "fail");
    result.textContent = "Resultado: " + percent + "%. " + (percent >= 80 ? "Unidad superada." : "Repasa los contenidos y vuelve a intentarlo.");
    completeCourse(percent);
  });

  window.addEventListener("beforeunload", function () {
    if (window.SCORM) {
      window.SCORM.finish();
    }
  });

  if (window.SCORM) {
    window.SCORM.init();
  }
  visited.intro = true;
  updateProgress();
})();
