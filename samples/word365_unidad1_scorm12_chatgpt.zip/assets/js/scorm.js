(function () {
  var apiHandle = null;
  var initialized = false;

  function findApi(win) {
    var attempts = 0;
    while (win && !win.API && win.parent && win.parent !== win && attempts < 7) {
      attempts += 1;
      win = win.parent;
    }
    return win && win.API ? win.API : null;
  }

  function getApi() {
    if (apiHandle) {
      return apiHandle;
    }
    apiHandle = findApi(window);
    if (!apiHandle && window.opener) {
      apiHandle = findApi(window.opener);
    }
    return apiHandle;
  }

  function call(method) {
    var api = getApi();
    if (!api || typeof api[method] !== "function") {
      return null;
    }
    try {
      return api[method].apply(api, Array.prototype.slice.call(arguments, 1));
    } catch (error) {
      return null;
    }
  }

  window.SCORM = {
    init: function () {
      if (initialized) {
        return true;
      }
      var result = call("LMSInitialize", "");
      initialized = result === "true" || result === true;
      if (initialized) {
        this.set("cmi.core.lesson_status", "incomplete");
        this.commit();
      }
      return initialized;
    },
    set: function (key, value) {
      if (!initialized) {
        return false;
      }
      return call("LMSSetValue", key + "", value + "") !== "false";
    },
    get: function (key) {
      if (!initialized) {
        return "";
      }
      return call("LMSGetValue", key + "") || "";
    },
    commit: function () {
      if (!initialized) {
        return false;
      }
      return call("LMSCommit", "") !== "false";
    },
    finish: function () {
      if (!initialized) {
        return false;
      }
      this.commit();
      var result = call("LMSFinish", "");
      initialized = false;
      return result !== "false";
    }
  };
})();
